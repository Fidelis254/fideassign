<?php 

return [
    'previous' => '＆laquo;前',
    'next' => '次へ＆raquo;',
];