<?php 

return [
    'failed' => 'Diese Anmeldeinformationen stimmen nicht mit unseren Unterlagen überein.',
    'throttle' => 'Zu viele Anmeldeversuche. Bitte versuchen Sie es erneut in: Sekunden Sekunden.',
];