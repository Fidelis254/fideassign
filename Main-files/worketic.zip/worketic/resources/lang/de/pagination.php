<?php 

return [
    'previous' => '& laquo; Bisherige',
    'next' => 'Weiter & raquo;',
];