<?php 

return [
    'failed' => '这些凭据与我们的记录不符。',
    'throttle' => '登录尝试次数过多。请再试一次：秒秒。',
];