<?php 

return [
    'previous' => 'Ve laquo; Önceki',
    'next' => 'Sonraki & raquo;',
];