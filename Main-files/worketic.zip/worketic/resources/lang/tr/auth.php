<?php 

return [
    'failed' => 'Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.',
    'throttle' => 'Çok fazla giriş yapma denemesi var. Lütfen tekrar deneyiniz: saniye saniye.',
];